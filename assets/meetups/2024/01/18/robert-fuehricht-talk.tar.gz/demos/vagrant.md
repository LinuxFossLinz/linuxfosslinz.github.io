# Create the lab

Launch vagrant

```
command vagrant up
sleep 120
```

[modeline]: # vim: nofoldenable:
